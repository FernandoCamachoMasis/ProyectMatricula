/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.curso;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class cursoDao {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public cursoDao() {
    }

    public List<curso> listarCurso() {
        List<curso> aux = new ArrayList<curso>();
        curso aux1 = new curso();
        String saveTableSQL
                = "Select "
                + "id_curso,"
                + "descripcion,"
                + "area_tematica_id "
                + "from curso;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setId_curso(rs.getInt("id_curso"));
                aux1.setDescripcion(rs.getString("descripcion"));
                aux1.setArea_tematica_id(rs.getInt("area_tematica_id"));

                aux.add(aux1);
                aux1 = new curso();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarCurso(curso a) {
        String saveTableSQL
                = "INSERT INTO curso("
                + "id_curso, "
                + "descripcion, "
                + "area_tematica_id) "
                + "VALUES (?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getId_curso());
            st.setString(2, a.getDescripcion());
            st.setInt(3, a.getArea_tematica_id());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public curso consultarCurso(int id) {
        curso aux = new curso();
        String saveTableSQL
                = "Select "
                + "id_curso,"
                + "descripcion,"
                + "area_tematica_id "
                + "from curso "
                + "where id_curso = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setId_curso(rs.getInt("id_curso"));
                aux.setDescripcion(rs.getString("descripcion"));
                aux.setArea_tematica_id(rs.getInt("area_tematica_id"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
