/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class usuarioDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public usuarioDAO() {
    }

    public List<usuario> listarUsuario() {
        List<usuario> aux = new ArrayList<usuario>();
        usuario aux1 = new usuario();
        String saveTableSQL
                = "Select "
                + "id_usuario,"
                + "rol_id,"
                + "clave, "
                + "ultimo_acceso,"
                + "activo "
                + "from usuario;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setId_usuario(rs.getString("id_usuario"));
                aux1.setRol_id(rs.getInt("rol_id"));
                aux1.setClave(rs.getString("clave"));
                aux1.setUltimo_acceso(rs.getDate("ultimo_acceso"));
                aux1.setActivo(rs.getInt("activo"));

                aux.add(aux1);
                aux1 = new usuario();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarUsuario(usuario a) {
        String saveTableSQL
                = "INSERT INTO usuario("
                + "id_usuario, "
                + "rol_id, "
                + "clave, "
                + "ultimo_acceso, "
                + "activo) "
                + "VALUES (?,?,?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setString(1, a.getId_usuario());
            st.setInt(2, a.getRol_id());
            st.setString(3, a.getClave());
            //st.setDate(4, a.getUltimo_acceso());
            st.setInt(5, a.getActivo());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public usuario consultarUsuario(int id) {
        usuario aux = new usuario();
        String saveTableSQL
                = "Select "
                + "id_usuario,"
                + "rol_id,"
                + "clave, "
                + "ultimo_acceso,"
                + "activo "
                + "from usuario "
                + "where id_usuario = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setId_usuario(rs.getString("id_usuario"));
                aux.setRol_id(rs.getInt("rol_id"));
                aux.setClave(rs.getString("clave"));
                aux.setUltimo_acceso(rs.getDate("ultimo_acceso"));
                aux.setActivo(rs.getInt("activo"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
