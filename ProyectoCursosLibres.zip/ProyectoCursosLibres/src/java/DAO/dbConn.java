/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author luisd
 */
public class dbConn {
    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_CONNECTION = "jdbc:mysql://localhost:3306/eif209_2021_01";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    private dbConn() {
    }

    //private static final Connection dbConnection = getDBConnection();

    public static Connection getDBConnection() {

        Connection conn = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);

            if (conn != null) {
                System.out.println("Conexión a base de datos " + DB_CONNECTION + " ... Ok");
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
        }
        return conn;
    }
}
