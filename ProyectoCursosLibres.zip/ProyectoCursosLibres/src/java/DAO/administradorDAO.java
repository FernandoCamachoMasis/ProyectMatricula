/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import Model.administrador;
import java.sql.PreparedStatement;

/**
 *
 * @author luisd
 */
public class administradorDAO {

    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public administradorDAO() {
    }

    public List<administrador> listarAdministrador() {
        List<administrador> aux = new ArrayList<administrador>();
        administrador aux1 = new administrador();
        String saveTableSQL
                = "Select "
                + "id_administrador,"
                + "usuario_id,"
                + "apellido1, "
                + "apellido2,"
                + "nombre,"
                + "telefono,"
                + "e_mail "
                + "from administrador;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setId_administrador(rs.getInt("id_administrador"));
                aux1.setUsuario_id(rs.getString("usuario_id"));
                aux1.setApellido1(rs.getString("apellido1"));
                aux1.setApellido2(rs.getString("apellido2"));
                aux1.setNombre(rs.getString("nombre"));
                aux1.setTelefono(rs.getString("telefono"));
                aux1.setE_mail(rs.getString("e_mail"));

                aux.add(aux1);
                aux1 = new administrador();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarAdministrador(administrador a) {
        String saveTableSQL
                = "INSERT INTO administrador("
                + "id_administrador, "
                + "usuario_id, "
                + "apellido1, "
                + "apellido2, "
                + "nombre, "
                + "telefono, "
                + "e_mail) "
                + "VALUES (?,?,?,?,?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getId_administrador());
            st.setString(2, a.getUsuario_id());
            st.setString(3, a.getApellido1());
            st.setString(4, a.getApellido2());
            st.setString(5, a.getNombre());
            st.setString(6, a.getTelefono());
            st.setString(7, a.getE_mail());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public administrador consultarAdministrador(int id) {
        administrador aux = new administrador();
        String saveTableSQL
                = "Select "
                + "id_administrador,"
                + "usuario_id,"
                + "apellido1, "
                + "apellido2,"
                + "nombre,"
                + "telefono,"
                + "e_mail "
                + "from administrador "
                + "where id_administrador = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setId_administrador(rs.getInt("id_administrador"));
                aux.setUsuario_id(rs.getString("usuario_id"));
                aux.setApellido1(rs.getString("apellido1"));
                aux.setApellido2(rs.getString("apellido2"));
                aux.setNombre(rs.getString("nombre"));
                aux.setTelefono(rs.getString("telefono"));
                aux.setE_mail(rs.getString("e_mail"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
