/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class rolDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public rolDAO() {
    }

    public List<rol> listarRol() {
        List<rol> aux = new ArrayList<rol>();
        rol aux1 = new rol();
        String saveTableSQL
                = "Select "
                + "id_rol,"
                + "descripcion "
                + "from rol;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setId_rol(rs.getInt("id_rol"));
                aux1.setDescripcion(rs.getString("descripcion"));

                aux.add(aux1);
                aux1 = new rol();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarRol(rol a) {
        String saveTableSQL
                = "INSERT INTO rol("
                + "id_rol, "
                + "descripcion) "
                + "VALUES (?,?,?,?,?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getId_rol());
            st.setString(2, a.getDescripcion());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public rol consultarRol(int id) {
        rol aux = new rol();
        String saveTableSQL
                = "Select "
                + "id_rol,"
                + "descripcion "
                + "from rol "
                + "where id_rol = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setId_rol(rs.getInt("id_rol"));
                aux.setDescripcion(rs.getString("descripcion"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
