/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.especialidad;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class especialidadDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public especialidadDAO() {
    }

    public List<especialidad> listarEspecialidad() {
        List<especialidad> aux = new ArrayList<especialidad>();
        especialidad aux1 = new especialidad();
        String saveTableSQL
                = "Select "
                + "profesor_id_profesor,"
                + "area_tematica_id "
                + "from especialidad;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setProfesor_id_profesor(rs.getInt("profesor_id_profesor"));
                aux1.setArea_tematica_id(rs.getInt("area_tematica_id"));

                aux.add(aux1);
                aux1 = new especialidad();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarEspecialidad(especialidad a) {
        String saveTableSQL
                = "INSERT INTO especialidad("
                + "profesor_id_profesor, "
                + "area_tematica_id) "
                + "VALUES (?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getProfesor_id_profesor());
            st.setInt(2, a.getArea_tematica_id());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public especialidad consultarEspecialidad(int id) {
        especialidad aux = new especialidad();
        String saveTableSQL
                = "Select "
                + "profesor_id_profesor,"
                + "area_tematica_id "
                + "from especialidad "
                + "where id_especialidad = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setProfesor_id_profesor(rs.getInt("profesor_id_profesor"));
                aux.setArea_tematica_id(rs.getInt("area_tematica_id"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
