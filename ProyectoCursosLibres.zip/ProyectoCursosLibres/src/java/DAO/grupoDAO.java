/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.grupo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class grupoDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public grupoDAO() {
    }

    public List<grupo> listarGrupo() {
        List<grupo> aux = new ArrayList<grupo>();
        grupo aux1 = new grupo();
        String saveTableSQL
                = "Select "
                + "num_grupo,"
                + "curso_id,"
                + "profesor_id "
                + "from grupo;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setNum_grupo(rs.getInt("num_grupo"));
                aux1.setCurso_id(rs.getInt("curso_id"));
                aux1.setProfesor_id(rs.getInt("profesor_id"));

                aux.add(aux1);
                aux1 = new grupo();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }
    
    public List<grupo> listarGrupos(int id) {
        List<grupo> aux = new ArrayList<grupo>();
        grupo aux1 = new grupo();
        String saveTableSQL
                = "Select "
                + "num_grupo,"
                + "curso_id,"
                + "profesor_id "
                + "from grupo "
                + "where curso_id = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setNum_grupo(rs.getInt("num_grupo"));
                aux1.setCurso_id(rs.getInt("curso_id"));
                aux1.setProfesor_id(rs.getInt("profesor_id"));

                aux.add(aux1);
                aux1 = new grupo();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }
    
    public List<grupo> listarGruposProfesor(int id) {
        List<grupo> aux = new ArrayList<grupo>();
        grupo aux1 = new grupo();
        String saveTableSQL
                = "Select "
                + "num_grupo,"
                + "curso_id,"
                + "profesor_id "
                + "from grupo "
                + "where profesor_id = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setNum_grupo(rs.getInt("num_grupo"));
                aux1.setCurso_id(rs.getInt("curso_id"));
                aux1.setProfesor_id(rs.getInt("profesor_id"));

                aux.add(aux1);
                aux1 = new grupo();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }
    
    public List<grupo> listarGruposIdProfesor(int cursoId, int ProfesorId) {
        List<grupo> aux = new ArrayList<grupo>();
        grupo aux1 = new grupo();
        String saveTableSQL
                = "Select "
                + "num_grupo, "
                + "curso_id, "
                + "profesor_id "
                + "from grupo "
                + "where curso_id = ? "
                + "and profesor_id = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, cursoId);
            st.setInt(2, ProfesorId);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setNum_grupo(rs.getInt("num_grupo"));
                aux1.setCurso_id(rs.getInt("curso_id"));
                aux1.setProfesor_id(rs.getInt("profesor_id"));

                aux.add(aux1);
                aux1 = new grupo();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarGrupo(grupo a) {
        String saveTableSQL
                = "INSERT INTO grupo("
                + "num_grupo, "
                + "curso_id, "
                + "profesor_id) "
                + "VALUES (?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getNum_grupo());
            st.setInt(2, a.getCurso_id());
            st.setInt(3, a.getProfesor_id());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public grupo consultarGrupo(int id) {
        grupo aux = new grupo();
        String saveTableSQL
                = "Select "
                + "num_grupo,"
                + "curso_id,"
                + "profesor_id "
                + "from grupo "
                + "where num_grupo = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setNum_grupo(rs.getInt("num_grupo"));
                aux.setCurso_id(rs.getInt("curso_id"));
                aux.setProfesor_id(rs.getInt("profesor_id"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
