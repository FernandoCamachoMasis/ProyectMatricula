/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.matricula;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class matriculaDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public matriculaDAO() {
    }

    public List<matricula> listarMatricula() {
        List<matricula> aux = new ArrayList<matricula>();
        matricula aux1 = new matricula();
        String saveTableSQL
                = "Select "
                + "estudiante_id,"
                + "grupo_num,"
                + "curso_id, "
                + "estado_id,"
                + "nota "
                + "from matricula;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setEstudiante_id(rs.getInt("estudiante_id"));
                aux1.setGrupo_num(rs.getInt("grupo_num"));
                aux1.setCurso_id(rs.getInt("curso_id"));
                aux1.setEstado_id(rs.getInt("estado_id"));
                aux1.setNota(rs.getInt("nota"));

                aux.add(aux1);
                aux1 = new matricula();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarMatricula(matricula a) {
        String saveTableSQL
                = "INSERT INTO matricula("
                + "estudiante_id, "
                + "grupo_num, "
                + "curso_id, "
                + "estado_id, "
                + "nota) "
                + "VALUES (?,?,?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getEstudiante_id());
            st.setInt(2, a.getGrupo_num());
            st.setInt(3, a.getCurso_id());
            st.setInt(4, a.getEstado_id());
            st.setInt(5, a.getNota());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public matricula consultarMatricula(int id) {
        matricula aux = new matricula();
        String saveTableSQL
                = "Select "
                + "estudiante_id,"
                + "grupo_num,"
                + "curso_id, "
                + "estado_id,"
                + "nota "
                + "from matricula "
                + "where estudiante_id = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setEstudiante_id(rs.getInt("estudiante_id"));
                aux.setGrupo_num(rs.getInt("grupo_num"));
                aux.setCurso_id(rs.getInt("curso_id"));
                aux.setEstado_id(rs.getInt("estado_id"));
                aux.setNota(rs.getInt("nota"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
