/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.estado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class estadoDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public estadoDAO() {
    }

    public List<estado> listarEstado() {
        List<estado> aux = new ArrayList<estado>();
        estado aux1 = new estado();
        String saveTableSQL
                = "Select "
                + "id_estado,"
                + "descripcion "
                + "from estado;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setId_estado(rs.getInt("id_estado"));
                aux1.setDescripcion(rs.getString("descripcion"));

                aux.add(aux1);
                aux1 = new estado();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarEstado(estado a) {
        String saveTableSQL
                = "INSERT INTO estado("
                + "id_estado, "
                + "descripcion) "
                + "VALUES (?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getId_estado());
            st.setString(2, a.getDescripcion());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public estado consultarEstado(int id) {
        estado aux = new estado();
        String saveTableSQL
                = "Select "
                + "id_estado,"
                + "descripcion "
                + "from estado "
                + "where id_estado = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setId_estado(rs.getInt("id_estado"));
                aux.setDescripcion(rs.getString("descripcion"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
