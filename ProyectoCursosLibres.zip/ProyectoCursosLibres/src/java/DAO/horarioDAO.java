/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.horario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luisd
 */
public class horarioDAO {
    public Connection cn;
    public PreparedStatement st;
    public ResultSet rs;
    public Statement s;

    public horarioDAO() {
    }

    public List<horario> listarHorario() {
        List<horario> aux = new ArrayList<horario>();
        horario aux1 = new horario();
        String saveTableSQL
                = "Select "
                + "seq,"
                + "grupo_num,"
                + "grupo_curso_id, "
                + "dia,"
                + "hora "
                + "from horario;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            rs = st.executeQuery();

            while (rs.next()) {
                aux1.setSeq(rs.getInt("seq"));
                aux1.setGrupo_num(rs.getInt("grupo_num"));
                aux1.setGrupo_curso_id(rs.getInt("grupo_curso_id"));
                aux1.setDia(rs.getInt("dia"));
                aux1.setHora(rs.getInt("hora"));

                aux.add(aux1);
                aux1 = new horario();
            }
            cn.close();
        } catch (Exception e) {
            System.out.print("Exception ");
            System.out.print(e.getMessage());
        }
        return aux;
    }

    public void insertarHorario(horario a) {
        String saveTableSQL
                = "INSERT INTO horario("
                + "seq, "
                + "grupo_num, "
                + "grupo_curso_id, "
                + "dia, "
                + "hora) "
                + "VALUES (?,?,?,?,?)";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);

            st.setInt(1, a.getSeq());
            st.setInt(2, a.getGrupo_num());
            st.setInt(3, a.getGrupo_curso_id());
            st.setInt(4, a.getDia());
            st.setInt(5, a.getHora());

            st.execute();

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
    }

    public horario consultarHorario(int id) {
        horario aux = new horario();
        String saveTableSQL
                = "Select "
                + "seq,"
                + "grupo_num,"
                + "grupo_curso_id, "
                + "dia,"
                + "hora "
                + "from horario "
                + "where seq = ?;";

        try {
            cn = dbConn.getDBConnection();
            st = cn.prepareStatement(saveTableSQL);
            st.setInt(1, id);
            rs = st.executeQuery();

            while (rs.next()) {
                aux.setSeq(rs.getInt("seq"));
                aux.setGrupo_num(rs.getInt("grupo_num"));
                aux.setGrupo_curso_id(rs.getInt("grupo_curso_id"));
                aux.setDia(rs.getInt("dia"));
                aux.setHora(rs.getInt("hora"));
            }

            cn.close();

        } catch (Exception e) {
            System.out.print("Exception");
            System.out.print(e.getMessage());
        }
        return aux;
    }
}
