/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author luisd
 */
public class usuario {
    private static final DateFormat FMT = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    
    private String id_usuario;
    private int rol_id;
    private String clave;
    private Date ultimo_acceso;
    private int activo;

    public usuario() {
    }

    public usuario(String id_usuario, int rol_id, String clave, Date ultimo_acceso, int activo) {
        this.id_usuario = id_usuario;
        this.rol_id = rol_id;
        this.clave = clave;
        this.ultimo_acceso = ultimo_acceso;
        this.activo = activo;
    }

    public String getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(String id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getRol_id() {
        return rol_id;
    }

    public void setRol_id(int rol_id) {
        this.rol_id = rol_id;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Date getUltimo_acceso() {
        return ultimo_acceso;
    }

    public void setUltimo_acceso(Date ultimo_acceso) {
        this.ultimo_acceso = ultimo_acceso;
    }

    public int getActivo() {
        return activo;
    }

    public void setActivo(int activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "usuario{" + "id_usuario=" + id_usuario + ", rol_id=" + rol_id + ", clave=" + clave + ", ultimo_acceso=" + ultimo_acceso + ", activo=" + activo + '}';
    }
    
}
