/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author luisd
 */
public class administrador {
    private int id_administrador;
    private String usuario_id;
    private String apellido1;
    private String apellido2;
    private String nombre;
    private String telefono;
    private String e_mail;

    public administrador() {
    }

    public administrador(int id_administrador, String usuario_id, String apellido1, String apellido2, String nombre, String telefono, String e_mail) {
        this.id_administrador = id_administrador;
        this.usuario_id = usuario_id;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.nombre = nombre;
        this.telefono = telefono;
        this.e_mail = e_mail;
    }

    public int getId_administrador() {
        return id_administrador;
    }

    public void setId_administrador(int id_administrador) {
        this.id_administrador = id_administrador;
    }

    public String getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(String usuario_id) {
        this.usuario_id = usuario_id;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getE_mail() {
        return e_mail;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }
    
    public String toString() {
        return "Administrador{" + "id_administrador=" + getId_administrador() + ", usuario_id=" + getUsuario_id() + ", apellido1=" + getApellido1() + ", apellido2=" + getApellido2() + ", nombre=" + getNombre() + ", telefono=" + getTelefono() + ", email=" + getE_mail() + '}';
    }    
}
