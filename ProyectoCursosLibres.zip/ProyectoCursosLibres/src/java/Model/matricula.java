/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author luisd
 */
public class matricula {
    private int estudiante_id;
    private int grupo_num;
    private int curso_id;
    private int estado_id;
    private int nota;

    public matricula() {
    }

    public matricula(int estudiante_id, int grupo_num, int curso_id, int estado_id, int nota) {
        this.estudiante_id = estudiante_id;
        this.grupo_num = grupo_num;
        this.curso_id = curso_id;
        this.estado_id = estado_id;
        this.nota = nota;
    }

    public int getEstudiante_id() {
        return estudiante_id;
    }

    public void setEstudiante_id(int estudiante_id) {
        this.estudiante_id = estudiante_id;
    }

    public int getGrupo_num() {
        return grupo_num;
    }

    public void setGrupo_num(int grupo_num) {
        this.grupo_num = grupo_num;
    }

    public int getCurso_id() {
        return curso_id;
    }

    public void setCurso_id(int curso_id) {
        this.curso_id = curso_id;
    }

    public int getEstado_id() {
        return estado_id;
    }

    public void setEstado_id(int estado_id) {
        this.estado_id = estado_id;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    @Override
    public String toString() {
        return "matricula{" + "estudiante_id=" + estudiante_id + ", grupo_num=" + grupo_num + ", curso_id=" + curso_id + ", estado_id=" + estado_id + ", nota=" + nota + '}';
    }
    
}
