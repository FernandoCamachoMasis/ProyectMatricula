/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author luisd
 */
public class curso {
    private int id_curso;
    private String descripcion;
    private int area_tematica_id;

    public curso() {
    }

    public curso(int id_curso, String descripcion, int area_tematica_id) {
        this.id_curso = id_curso;
        this.descripcion = descripcion;
        this.area_tematica_id = area_tematica_id;
    }

    public int getId_curso() {
        return id_curso;
    }

    public void setId_curso(int id_curso) {
        this.id_curso = id_curso;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getArea_tematica_id() {
        return area_tematica_id;
    }

    public void setArea_tematica_id(int area_tematica_id) {
        this.area_tematica_id = area_tematica_id;
    }
    
    public String toString() {
        return "Curso{" + "id_curso=" + getId_curso() + ", descripcion=" + getDescripcion() + ", id_area_tematica=" + getArea_tematica_id() + '}';
    }
}
