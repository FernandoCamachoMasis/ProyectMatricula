package Servicios;

import DAO.estadoDAO;
import DAO.estudianteDAO;
import DAO.matriculaDAO;
import Model.estado;
import Model.estudiante;
import Model.matricula;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author luisd
 */
@WebServlet(name = "servicioGruposEstudiante", urlPatterns = {"/servicioGruposEstudiante"})
public class servicioGruposEstudiante extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public int curso;
    public int grupo;
    HttpServletRequest request1;
    HttpServletResponse response1;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                System.out.println("Grupo " + grupo + " Curso " + curso);
                if (request.getParameter("btn_actualizarEst") != null) {
                    matriculaDAO md = new matriculaDAO();
                    matricula m = new matricula(Integer.valueOf(request.getParameter("btn_actualizarEst")),
                            grupo,
                            curso,
                            0,
                            Integer.valueOf(request.getParameter("Nota")));
                    if (Integer.valueOf(request.getParameter("Nota")) >= 70) {
                        m.setEstado_id(1);
                    }
                    try {
                        md.actualizarMatricula(m);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }

                    request.getRequestDispatcher("servicioGruposEstudiante").forward(request1, response1);
                } else {
                    matriculaDAO md = new matriculaDAO();
                    List<matricula> m = new ArrayList();
                    m = md.listarMatriculaByCursoGrupo(
                            Integer.valueOf(request.getParameter("btn_grupoProfe")),
                            (int) request.getSession().getAttribute("cursoID"));
                    request.getSession().setAttribute("listMatriculaGrupo", m);

                    estudianteDAO estd = new estudianteDAO();
                    List<estudiante> est = new ArrayList();
                    for (matricula index : m) {
                        est.add(estd.consultarEstudiante(index.getEstudiante_id()));
                    }
                    request.getSession().setAttribute("listEstudiantes", est);

                    estadoDAO ed = new estadoDAO();
                    List<estado> e = new ArrayList();
                    e = ed.listarEstado();
                    request.getSession().setAttribute("listEstados", e);
                    request.getSession().setAttribute("grupoID", request.getParameter("btn_grupoProfe"));
                    grupo = Integer.valueOf(request.getParameter("btn_grupoProfe"));
                    curso = (int) request.getSession().getAttribute("cursoID");
                    request1 = request;
                    response1 = response;
                    response.sendRedirect("estudiantes.jsp");
                }
            } catch (NumberFormatException e) {
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
