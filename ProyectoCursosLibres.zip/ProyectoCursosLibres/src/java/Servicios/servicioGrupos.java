package Servicios;

import DAO.cursoDao;
import DAO.grupoDAO;
import DAO.matriculaDAO;
import DAO.profesorDAO;
import Model.curso;
import Model.grupo;
import Model.matricula;
import Model.profesor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author luisd
 */
@WebServlet(name = "servicioGrupos", urlPatterns = {"/servicioGrupos"})
public class servicioGrupos extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            if (request.getParameter("btn_grupo") != null) {
                matriculaDAO md = new matriculaDAO();
                matricula m
                        = new matricula(117580365,
                                Integer.valueOf(request.getParameter("btn_grupo")),
                                (int) request.getSession().getAttribute("cursoID"),
                                1,
                                0);
                try {
                    md.insertarMatricula(m);
                    request.getSession().setAttribute("Message", "Succesful");
                } catch (Exception e) {
                    request.getSession().setAttribute("Message", e.getMessage());
                }
                response.sendRedirect("servicioCursos");
            } else {
                grupoDAO gd = new grupoDAO();
                List<grupo> lm = new ArrayList();
                lm = gd.listarGrupos(Integer.valueOf(request.getParameter("btn_tabla")));
                request.getSession().setAttribute("listGrupos", lm);

                profesorDAO pd = new profesorDAO();
                List<profesor> lp = new ArrayList();
                lp = pd.listarProfesor();
                request.getSession().setAttribute("listProfesores", lp);

                cursoDao cd = new cursoDao();
                curso c = cd.consultarCurso(Integer.valueOf(request.getParameter("btn_tabla")));
                request.getSession().setAttribute("cursoDesc", c.getDescripcion());
                request.getSession().setAttribute("cursoID", c.getId_curso());

                response.sendRedirect("grupos.jsp");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
