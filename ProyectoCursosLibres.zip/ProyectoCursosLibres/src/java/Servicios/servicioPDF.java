package Servicios;

import DAO.matriculaDAO;
import Model.matricula;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Font;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author mauri
 */
public class servicioPDF extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws com.itextpdf.text.DocumentException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, DocumentException {
        response.setContentType("application/pdf");
        try (OutputStream out = response.getOutputStream()) {
            matriculaDAO md = new matriculaDAO();
            List<matricula> lm = new ArrayList();
            lm = md.listarMatricula();
            Document docPDF = new Document();
            PdfWriter.getInstance(docPDF, out);
            docPDF.open();
            Paragraph titulo = new Paragraph("HISTORIAL DE CURSOS \n\n", FontFactory.getFont("arial", 16, Font.BOLD, BaseColor.BLACK));
            titulo.setAlignment(Element.ALIGN_CENTER);
            docPDF.add(titulo);
            PdfPTable tabla = new PdfPTable(4);
            PdfPCell grupo = new PdfPCell(new Phrase("Grupo"));
            grupo.setBackgroundColor(BaseColor.GRAY);
            grupo.setBorderColor(BaseColor.BLACK);
            tabla.addCell(grupo);
            PdfPCell curso = new PdfPCell(new Phrase("Curso"));
            curso.setBackgroundColor(BaseColor.GRAY);
            curso.setBorderColor(BaseColor.BLACK);
            tabla.addCell(curso);
            PdfPCell estado = new PdfPCell(new Phrase("Estado"));
            estado.setBackgroundColor(BaseColor.GRAY);
            estado.setBorderColor(BaseColor.BLACK);
            tabla.addCell(estado);
            PdfPCell nota = new PdfPCell(new Phrase("Nota"));
            nota.setBackgroundColor(BaseColor.GRAY);
            nota.setBorderColor(BaseColor.BLACK);
            tabla.addCell(nota);
            for (int i = 0; i < lm.size(); i++) {
                
                PdfPCell celda1 = new PdfPCell(new Phrase(String.valueOf(lm.get(i).getGrupo_num())));
                celda1.setBackgroundColor(BaseColor.LIGHT_GRAY);
                celda1.setBorderColor(BaseColor.BLACK);
                tabla.addCell(celda1);
                
                PdfPCell celda2 = new PdfPCell(new Phrase(String.valueOf(lm.get(i).getCurso_id())));
                celda2.setBackgroundColor(BaseColor.LIGHT_GRAY);
                celda2.setBorderColor(BaseColor.BLACK);
                tabla.addCell(celda2);
                
                PdfPCell celda3 = new PdfPCell(new Phrase(String.valueOf(lm.get(i).getEstado_id())));
                celda3.setBackgroundColor(BaseColor.LIGHT_GRAY);
                celda3.setBorderColor(BaseColor.BLACK);
                tabla.addCell(celda3);
                
                PdfPCell celda4 = new PdfPCell(new Phrase(String.valueOf(lm.get(i).getNota())));
                celda4.setBackgroundColor(BaseColor.LIGHT_GRAY);
                celda4.setBorderColor(BaseColor.BLACK);
                tabla.addCell(celda4);
                
            }
            docPDF.add(tabla);
            docPDF.close();
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (DocumentException ex) {
            Logger.getLogger(servicioPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (DocumentException ex) {
            Logger.getLogger(servicioPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
